import React, {useState} from "react";
import QrReader from "react-qr-reader";
import PdfViewerComponent from "./PdfViewerComponent";
import './App.css';
import { Alert, Button } from 'react-bootstrap';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

var CryptoJS = require("crypto-js");


function ReadQr(props){
    
    const [scanResultWebCam, setScanResultWebCam] = useState('') 
    const [ScannedResult, setScannedResult] = useState('Unscanned')
    const [HashResult, setHashResult] = useState('')
    const [SkResult, setSkResult] = useState('')
    const [LinkResult, setLinkResult] = useState('')
    const [Result, setResult] = useState('')
    const handleErrorWebCam = (error) =>{
        console.log(error)
    }
    const handleErrorScanWebCam = (result) => {
        if (result){
            setScanResultWebCam(result)
            setScannedResult('Scanned')
            setHashResult(scanResultWebCam.substr(0,107))
            setSkResult(scanResultWebCam.substr(108))
            console.log('Hash : ',HashResult,' Secret Key : ',SkResult)
        }
    }

    
    

return(
    <div className="App" class="center">
      <h1>Scan QR</h1>
      <form onSubmit={(event) => {
            event.preventDefault()
            var Hash=''
            var Sk=''
            if(scanResultWebCam!==''){
                Hash=scanResultWebCam.substr(0,108)
                Sk=scanResultWebCam.substr(108)
                var bytes = CryptoJS.AES.decrypt(Hash, Sk)
                var decryptedData = bytes.toString(CryptoJS.enc.Utf8)
                setResult('Data Invalid')
                var link =''
                props.Hash.map((hash, key) => {
                    if(hash.hash===decryptedData){
                        setResult('Data Valid')
                        link="https://"+hash.hash+".ipfs.infura-ipfs.io"
                    }
                })
                console.log('Qr : ',scanResultWebCam)
                console.log('Encrypted Hash : ',Hash,' Secret Key : ',Sk,' Decrypted Hash : ',decryptedData)
                // console.log('Hasil : ',res,' Link : ',link)
                props.setDocument(Result)
                setLinkResult(link)
                console.log('Hasil : ',props.document,' Link : ',link)
            }
            // props.storeHash(Cid)
            // console.log(Cid)    
        }}>
            <QrReader 
                delay={300}
                style={{width: '300px'}}
                onError={handleErrorWebCam}
                onScan={handleErrorScanWebCam}
            />
            <h3>Scanned Status: {ScannedResult}</h3>
            <h3><button type="submit" className="btn btn-primary">Search</button></h3>
        </form>
        {(()=>{
                        if(scanResultWebCam!==''){
                            if(Result!=='Data Invalid'){
                                if(LinkResult!==''){
                                    return(
                                        <div className="row">
                                            <PdfViewerComponent document={LinkResult}/>
                                        </div>
                                    )
                                }
                            }else{
                                return(
                                <alert>TIDAK VALID!</alert>
                                )
                            }
                        }
                        })()} 
        {/* <Router>
            <Link to="/doc">
                        <Button variant="primary">Tampil Pdf</Button>{' '}
            </Link>
            <Switch>
                <Route path="/doc">
                    {(()=>{
                        if(scanResultWebCam!==''){
                            if(Result!=='Data Invalid'){
                                return(
                                    <div className="row">
                                        <PdfViewerComponent document={LinkResult}/>
                                    </div>
                                )
                            }else{
                                return(
                                <alert>GAK VALID!</alert>
                                )
                            }
                        }else{
                            return(
                                <alert>PINDAI DULU GOBLOK!</alert>
                            )
                        }
                        })()} 
                </Route>
            </Switch>
        </Router> */}
        {/* {props.Hash.map((hash, key) => {
                return(
                    <tr key={key}>
                        <td>Hash :{hash.hash}</td> 
                        <td>Time :{hash.time.toString()}</td>
                    </tr>
                    
                )
            })} */}
    </div>
)
}
export default ReadQr;