import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from "react";
import { Button, Form } from 'react-bootstrap'
var CryptoJS = require("crypto-js");


const Aesdec = (props) => {
    const [getInputCid, setInputCid] = useState('')

    const handleSubmit = (event) => {
      event.preventDefault()
      var enCid=getInputCid
      var bytes = CryptoJS.AES.decrypt(enCid, 'my-secret-key@123')
      var decryptedData = bytes.toString(CryptoJS.enc.Utf8)
      console.log("Encrypted CID = ",enCid)
      console.log("Aes Decrypted = ", decryptedData)
    }

    const handleEventCid = (event) => {
      setInputCid(event.target.value)
      //console.log(getInputCid)
    }

    return (
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Decrypted</Form.Label>
            <Form.Control type="cid" placeholder="ENTER ENCRYPTED CID" onChange={handleEventCid}/>
          </Form.Group>
          <Button variant="primary" type="submit">
            Decrypt
          </Button>
        </Form>
    )
}

export default Aesdec; 