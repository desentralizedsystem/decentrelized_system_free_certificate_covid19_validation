import React, { Component } from 'react';

class Main extends Component {

  render() {
    return (
      <div id="content">
        <h1>Add Hash</h1>
        <form onSubmit={(event) => {
          event.preventDefault()
          const hash = this.Cid.value
          this.props.storeHash(hash)    
        }}>
          <div className="form-group mr-sm-3">
            <input
              id="Cid"
              type="text"
              ref={(input) => { this.Cid = input }}
              className="form-control"
              placeholder="CID"
              required />
          </div> 
          <button type="submit" className="btn btn-primary">Upload</button>
        </form>
        <p>&nbsp;</p>
      </div>
    );
  }
}

export default Main;
