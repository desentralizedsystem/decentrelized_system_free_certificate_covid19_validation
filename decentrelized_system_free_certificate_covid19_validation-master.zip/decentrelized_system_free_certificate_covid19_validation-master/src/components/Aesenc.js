import 'bootstrap/dist/css/bootstrap.min.css';
import { useState } from "react";
import { Button, Form } from 'react-bootstrap'
import Qrcode from "./Qrcode"
var CryptoJS = require("crypto-js");


const Aes = (props) => {
    const [getInputCid, setInputCid] = useState('')

    const handleSubmit = (event) => {
      event.preventDefault()
      var newCid=getInputCid
      var ciphertext = CryptoJS.AES.encrypt(newCid, 'my-secret-key@123').toString();
      console.log("CID = ",newCid)
      console.log("Aes Encrypted = ", ciphertext)
    }

    const handleEventCid = (event) => {
      setInputCid(event.target.value)
      //console.log(getInputCid)
    }

    return (
        <Form onSubmit={handleSubmit}>
          <Form.Group className="mb-3" controlId="formBasicPassword">
            <Form.Label>Encrypt CID</Form.Label>
            <Form.Control type="xcid" placeholder="ENTER CID" onChange={handleEventCid}/>
          </Form.Group>
          <Button variant="primary" type="submit">
            Encrypt
          </Button>
        </Form>
    )
}

export default Aes; 