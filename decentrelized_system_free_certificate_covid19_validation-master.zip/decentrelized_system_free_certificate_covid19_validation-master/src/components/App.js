import React, { Component } from 'react';
import Web3 from 'web3';
import './App.css';
import Covid from '../abis/covid.json';
import Navbar from './Navbar';
import Post from './Post';
import { Button } from 'react-bootstrap';
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import IpfsUp from './IpfsUp';
import ReadQr from './ReadQr';



class App extends Component {

  async componentWillMount() {
    await this.loadWeb3()
    await this.loadBlockchainData()
  }

  async loadBlockchainData() {
    const web3 = window.web3
    const accounts = await web3.eth.getAccounts()
    console.log(accounts)
    this.setState({ account: accounts[0] })
    const netID = await web3.eth.net.getId()
    const netData = Covid.networks[netID]
    if (netData) {
      const covid = web3.eth.Contract(Covid.abi, Covid.networks[5777].address)
      this.setState({ covid })
      this.setState({ loading: false })
      const idHashs = await covid.methods.idHash().call()
      this.setState({idHash : idHashs})
      for(var index = 0; index < this.state.idHash; index++){
        const hash = await covid.methods.sHash(index).call()
        this.setState(
          {
            Hash : [...this.state.Hash, hash] 
          }
        )
      }
      console.log(this.state.idHash.toString())
      console.log(this.state.Hash)
    } else {
      window.alert('Covid contract not deployed to detected network')
    }
    console.log(netID)
  }

  constructor(props) {
    super(props)
    this.state = {
      account: '',
      idHash: 0,
      Hashs: 0,
      Hash: [],
      loading: true,
      document: ''
    }
    this.storeHash = this.storeHash.bind(this)
    this.setDocument = this.setDocument.bind(this)

  }

  async loadWeb3() {
    if (window.ethereum) {
      window.web3 = new Web3(window.ethereum)
      await window.ethereum.enable()
    }
    else if (window.web3) {
      window.web3 = new Web3(window.web3.currentProvider)
    }
    else {
      window.alert('Non-Ethereum browser detected. You should consider trying MetaMask!')
    }
  }

  storeHash(hash) {
    this.setState({ loading: true })
    this.state.covid.methods.storeHash(hash).send({ from: this.state.account }).once('receipt', (receipt) => {
      this.setState({ loading: false })
    })
  }

  setDocument(link){
    this.setState({
      document: link
    });
  }
  render() {
    return (
      <div>
        <Navbar account={this.state.account} />
        <Router>
          <div className="container-fluid mt-5">
            <ul>
            <li>
                <div className="row">
                  <Link to="/PDF">
                    <Button variant="primary">Test PDF</Button>{' '}
                  </Link>
                </div>
              </li>
              <li>
                <div className="row">
                  <Link to="/Up">
                    <Button variant="primary">Upload File</Button>{' '}
                  </Link>
                </div>
              </li>
              <li>
                <div className="row mt-3">
                  <Link to="/Main">
                    <Button variant="primary">Scan QR</Button>{' '}
                  </Link>
                </div>
              </li>
            </ul>
            {/* <div className="row">
              <main role="main"  className="col-lg-12 d-flex">
                { this.state.loading 
                ? <div id="loader" className="text-center"><p className="text-center">Loading...</p></div>
                : <Main storeHash={this.storeHash} /> 
                }
              </main>
            </div> */}
          </div>

          {/* A <Switch> looks through its children <Route>s and
            renders the first one that matches the current URL. */}

          <Switch>
          <Route path="/PDF">
              <div className="row">
                <main role="main" className="col-lg-12 d-flex">
                  {this.state.loading
                    ? <div id="loader" className="text-center"><p className="text-center">Loading...</p></div>
                    : <Post />
                  }
                </main>
              </div>
            </Route>
            <Route path="/Up">
              <div className="row">
                <main role="main" className="col-lg-12 d-flex">
                  {this.state.loading
                    ? <div id="loader" className="text-center"><p className="text-center">Loading...</p></div>
                    : <IpfsUp storeHash={this.storeHash}/>
                  }
                </main>
              </div>
            </Route>
            <Route path="/Main">
            <div className="row">
                <main role="main" className="col-lg-12 d-flex">
                  {this.state.loading
                    ? <div id="loader" className="text-center"><p className="text-center">Loading...</p></div>
                    : <ReadQr Hash={this.state.Hash} setDocument={this.setDocument} document={this.state.document}/>
                  }
                </main>
              </div>
            </Route>
          </Switch>
        </Router>
      </div>
    );
  }
}

export default App;
