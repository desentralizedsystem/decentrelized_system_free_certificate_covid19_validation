import './App.css'
import React, { Component }  from 'react';
import { useState } from 'react'
import { create } from 'ipfs-http-client'
import QRCode from 'qrcode';
const client = create('https://ipfs.infura.io:5001/api/v0')
var CryptoJS = require("crypto-js");

class Up extends Component {
  // const [fileUrl, updateFileUrl] = useState(``)
  // const [Qcodes, setQcodes] = useState('')
  // const [Cid, setCid] = useState('')
  async genQr(chipertext,Sk){
    try {
      var Qc=chipertext+Sk
      const response = QRCode.toDataURL(Qc)
      this.setState({ 
        FileUrl: response,
        Qcode: Qc
      })
    }catch(error){
      console.log(error)
    }
  }
  constructor(props){
    super(props)
    this.state = {
      Qcode: '',
      Cid: '',
      FileUrl: '',
      loading: true
    }
  } 

  render(){
    return (
      <div className="Up">
        <h1>Upload Data</h1>
        <form onSubmit={(event) => {
            event.preventDefault()
            const hash = this.Cid.value
            this.props.storeHash(hash)    
          }}>
            <input
              type="file"
              onChange={e => {
                e.preventDefault()
                const file = e.target.files[0]
                try {
                  const added = client.add(file)
                  var newCid = added.cid.toV1().toString()
                  var Sk = newCid.substr(0, 8)
                  var ciphertext = CryptoJS.AES.encrypt(newCid, Sk).toString()
                  //const url = `https://ipfs.infura.io/ipfs/${added.path}`
                  this.genQr(ciphertext,Sk)
                  this.setState({
                    Cid: newCid
                  })
                  console.log("CID : ", newCid, "Secret Key : ", Sk, " Encrypted CID : ", ciphertext, " QR : ", this.state.Qcode)
                } catch (error) {
                  console.log('Error uploading file: ', error)
                }
              }}
            /> 
            {
              this.FileUrl.value && (
                <img src={this.FileUrl.value} width="600px" />
              )
            }
            <button type="submit" className="btn btn-primary">Upload</button>
        </form>
      </div>
    );
  }
}

export default Up