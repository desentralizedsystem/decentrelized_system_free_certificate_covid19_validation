import './App.css'
import { useState } from 'react'
import { create } from 'ipfs-http-client'
import QRCode from 'qrcode'
import React, { Component }  from 'react'
const client = create('https://ipfs.infura.io:5001/api/v0')
var CryptoJS = require("crypto-js")

function IpfsUp(props) {
  const [fileUrl, updateFileUrl] = useState(``)
  const [Cid, updateCid] = useState(``)
  async function onChange(e) {
    const file = e.target.files[0]
    try {
      const added = await client.add(file)
    //   const url = `https://ipfs.infura.io/ipfs/${added.path}`
      var newCid = added.cid.toV1().toString()
      var Sk = newCid.substr(0, 8)
      var ciphertext = CryptoJS.AES.encrypt(newCid, Sk).toString()
      var Qr = ciphertext+Sk
      const response = (await QRCode.toDataURL(Qr)).toString()
      updateFileUrl(response)
      updateCid(newCid)
      console.log('Cid : ',newCid,' Secret Key : ',Sk,' En Cid : ',ciphertext,' Qr : ',Qr)
      //const url = `https://ipfs.infura.io/ipfs/${added.path}`
    } catch (error) {
      console.log('Error uploading file: ', error)
    }  
  }
  return (
    <div className="App">
      {(()=>{
        if(Cid!==''){
            return(
                  <h1>IPFS Cid : {Cid}</h1>    
            )
           }
        })()}
       <form onSubmit={(event) => {
            event.preventDefault()
            props.storeHash(Cid)
            console.log(Cid)    
          }}> 
        <input
            type="file"
            onChange={onChange}
            required
        />
        {
            fileUrl && (
            <img src={fileUrl} width="600px" />
            )
        }
        <button type="submit" className="btn btn-primary">Upload</button>
       </form> 
    </div>
  )
}

export default IpfsUp