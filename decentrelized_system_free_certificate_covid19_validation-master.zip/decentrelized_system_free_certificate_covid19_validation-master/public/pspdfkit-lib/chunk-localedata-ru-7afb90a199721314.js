/*!
 * PSPDFKit for Web 2021.6.1 (https://pspdfkit.com/web)
 *
 * Copyright (c) 2016-2021 PSPDFKit GmbH. All rights reserved.
 *
 * THIS SOURCE CODE AND ANY ACCOMPANYING DOCUMENTATION ARE PROTECTED BY INTERNATIONAL COPYRIGHT LAW
 * AND MAY NOT BE RESOLD OR REDISTRIBUTED. USAGE IS BOUND TO THE PSPDFKIT LICENSE AGREEMENT.
 * UNAUTHORIZED REPRODUCTION OR DISTRIBUTION IS SUBJECT TO CIVIL AND CRIMINAL PENALTIES.
 * This notice may not be removed from this file.
 *
 * PSPDFKit uses several open source third-party components: https://pspdfkit.com/acknowledgements/web/
 */
(self.webpackChunkPSPDFKit=self.webpackChunkPSPDFKit||[]).push([[1385],{88821:function(){Intl.PluralRules&&"function"==typeof Intl.PluralRules.__addLocaleData&&Intl.PluralRules.__addLocaleData({data:{ru:{categories:{cardinal:["one","few","many","other"],ordinal:["other"]},fn:function(a,e){var l=String(a).split("."),n=l[0],t=!l[1],r=n.slice(-1),o=n.slice(-2);return e?"other":t&&1==r&&11!=o?"one":t&&r>=2&&r<=4&&(o<12||o>14)?"few":t&&0==r||t&&r>=5&&r<=9||t&&o>=11&&o<=14?"many":"other"}}},availableLocales:["ru"]})}}]);