const Covid = artifacts.require("Covid");

module.exports = function(deployer) {
  deployer.deploy(Covid);
};
